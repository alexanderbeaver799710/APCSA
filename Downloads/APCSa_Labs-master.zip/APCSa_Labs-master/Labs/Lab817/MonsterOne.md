# Lab 817::Drawing Shapes with p5 #

###Objectives###
 - Create a new p5 project
 - Draw various shapes with p5
 - Create a monster with p5


##Part I: Add a project to you home drive##
 - On your Home Drive (H), create a folder for labs.  Inside the labs folder create a folder named "Lab817MonsterOne"
 - From the E17 share folder, copy the StartTemplate into your Lab817 folder
 - Rename the "StartTemplate" folder to "MonsterOne"</br>
 - Make sure the following are in your project folder
 
  ![image](img1.png)

 - Open the project folder in Atom or drag **jspage.html** into Notepad++

###Part II: Draw various shapes on the canvas###

 -  Go to the p5js reference and experiment with the following shapes:
	 -  rect( )
	 -  ellipse( )
	 -  triangle( )
	 -  

####Part III: Go to the p5js reference and experiment with the following shapes
 - Through Google, find the p5 reference.  add other shapes to your project





----


