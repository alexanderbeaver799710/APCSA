//� A+ Computer Science  -  www.apluscompsci.com

//while loop example 2

public class WhileTwo
{
   public static void main(String args[])
   {
		int run=25;
		while(run>=10)
		{
		   System.out.println(run);
		   System.out.println("loop");
		   run=run-5;
		}
	}
}
