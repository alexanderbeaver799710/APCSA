//� A+ Computer Science  -  www.apluscompsci.com

//while loop example 1

public class WhileOne
{
   public static void main(String args[])
   {
		int run = 0;   					//0 - Start
		while(run<5)  						//1 - Stop
		{
		   run = run + 1;     			//2 - increment
		   System.out.println(run);	//3 - code

		   //add code to print your name
		   System.out.println("ALEX");
		}
	}
}
