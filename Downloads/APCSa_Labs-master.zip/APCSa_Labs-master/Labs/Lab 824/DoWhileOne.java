//� A+ Computer Science  -  www.apluscompsci.com

//do while loop example 1

public class DoWhileOne
{
   public static void main(String args[])
   {
		int run=0;   							//0 - start
		do
		{
		   run = run + 1;      				//1 - increment
		   System.out.println(run);   	//2 - code
		} while(run<4);    					//3 - stop
	}
}
