//� A+ Computer Science  -  www.apluscompsci.com

//do while loop example 2

public class DoWhileTwo
{
   public static void main(String args[])
   {
		int run=25;
		do{
		   System.out.println(run);
		   System.out.println("loop");
		   run=run-5;
		} while(run>=10);
		//Final value 5
	}
}
