//� A+ Computer Science  -  www.apluscompsci.com

//while loop example 3

public class WhileThree
{
   public static void main(String args[])
   {
		int run=10;
		while(run<=25)
		{
		   System.out.println(run);
		   System.out.println("loop");
		   run=run+5;
		}
	}
}
