

//� A+ Computer Science  -  www.apluscompsci.com

//do while loop example 3

public class DoWhileThree{public static void main(String args[]){int run=10;do{System.out.println(run);System.out.println("loop");run=run+5;} while(run<=25);}}}
