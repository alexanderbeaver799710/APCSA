
/**
 * Write a description of class ArrayTest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ArrayTest
{
    public static void main(){
        for(int i = 0; i < 100; i++){
            System.out.println((int)(Math.random()*10 + 1) + ", ");
        }
        
    }
}
