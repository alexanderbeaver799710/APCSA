//� A+ Computer Science
// www.apluscompsci.com

//for loop example 3

import static java.lang.System.*;

public class ForThree
{
	public static void main(String args[])
	{
		for(int run=7; run>2; run=run-2)	//change the stop and decrement
		{
		   out.println("loop");
		   out.println(run);
		}
	}
}
