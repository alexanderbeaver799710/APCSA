//� A+ Computer Science
// www.apluscompsci.com

//uil for loop example

import static java.lang.System.*;

public class ForUIL
{
	public static void main(String args[])
	{
		out.println("cs contests are fun!");
		for(int uil=5; uil>=1; uil--)
		{
		   out.print("state-");
		}
		out.println("\nchamps");
	}
}
