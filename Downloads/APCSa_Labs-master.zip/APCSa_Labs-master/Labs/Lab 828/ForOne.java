//� A+ Computer Science
// www.apluscompsci.com

//for loop example 1

import static java.lang.System.*;

public class ForOne
{
	public static void main(String args[])
	{
	           //Start	  Stop      Increment
		for(int  run=1;   run<=10;   run=run+1)
		{
		   out.println(run);
		}
	}
}
