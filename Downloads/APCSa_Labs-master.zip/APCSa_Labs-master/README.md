# APCSa_Labs

Hello. This is my repo for _labs_ for the 2018-2019 school year of AP Computer Science A. It should end up being a mirror of H:/abeaver/labs, once GH Desktop is ghosted to all of the computers.
